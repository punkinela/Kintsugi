# Airline Sentiment Analysis - Setup Guide

This guide will help you set up the Airline Sentiment Analysis project on your local machine and create a bolt.new web app.

## 📋 What You Have

In this repository, you have:

1. **TColon_NLP_Algo_Harness.ipynb** - Original Colab notebook with ML models
2. **bolt-app-airline-sentiment.md** - Complete bolt.new web app code
3. **sentimentAnalysis.ts** - Sentiment analysis utilities (TypeScript)

## 🎯 Two Main Use Cases

### Option A: Create the Bolt.new Web App

The `bolt-app-airline-sentiment.md` file contains EVERYTHING you need to create a fully functional airline sentiment analysis web app on bolt.new.

**Steps:**
1. Go to https://bolt.new
2. Create a new React project
3. Open `bolt-app-airline-sentiment.md` in this repository
4. Follow the instructions in that file to copy each code section
5. The app will auto-build!

**What the bolt.new app includes:**
- Real-time tweet sentiment analysis
- Interactive UI with sentiment visualization
- Model comparison charts showing all 7 ML algorithms
- Analysis history tracking
- Sample tweets to try

### Option B: Use the Sentiment Analysis Utilities

The `sentimentAnalysis.ts` file provides reusable sentiment analysis functions you can integrate into any TypeScript/JavaScript project.

**Key functions:**
- `analyzeSentiment(text)` - Analyze sentiment of any text
- `analyzeEntriesSentiment(entries)` - Batch analysis
- `detectPatterns(entries)` - Find recurring themes
- `identifyGoldenSeams(entries)` - Detect challenge → recovery → win patterns
- `getResilienceScore(seams)` - Calculate resilience metrics

## 🚀 Quick Start (Recommended)

### For Bolt.new App:

1. **Clone this repository:**
   ```bash
   git clone https://github.com/punkinela/Airline.git
   cd Airline
   ```

2. **Open bolt-app-airline-sentiment.md** and follow the detailed instructions inside

3. **Go to bolt.new** and paste the code sections as directed

### For Custom Integration:

1. Copy `sentimentAnalysis.ts` into your project
2. Import the functions you need:
   ```typescript
   import { analyzeSentiment } from './sentimentAnalysis';

   const result = analyzeSentiment("Great flight, amazing service!");
   console.log(result); // { score, label, confidence }
   ```

## 📊 What Makes This Different from Kintsugi?

This repository is **completely separate** from the Kintsugi app:

- **Kintsugi**: Personal engagement tracking and journaling app
- **Airline Sentiment**: ML-powered airline tweet sentiment analysis
  - Uses the Twitter US Airline Sentiment dataset
  - 7 different ML models (Logistic Regression, Naive Bayes, Random Forest, etc.)
  - Focused on airline industry feedback analysis
  - Web-based sentiment analyzer tool

## 🔧 Technical Details

**Dataset:** Twitter US Airline Sentiment (~14,640 tweets)

**ML Models Compared:**
- Logistic Regression (90.95% accuracy)
- Naive Bayes
- Random Forest
- Gradient Boosting
- XGBoost
- LightGBM (Best ROC-AUC: 0.7745)
- CatBoost

**NLP Techniques:**
- TF-IDF vectorization
- Stopword removal
- Lemmatization
- Keyword-based sentiment scoring

## 📁 File Structure

```
Airline/
├── README.md
├── TColon_NLP_Algo_Harness.ipynb    # Original ML notebook
├── bolt-app-airline-sentiment.md    # Complete bolt.new app code
├── sentimentAnalysis.ts              # Reusable sentiment utilities
└── SETUP-GUIDE.md                    # This file
```

## 🎨 Next Steps

1. **Try the bolt.new app first** - It's the easiest way to see everything in action
2. **Explore the Jupyter notebook** - See the ML model training process
3. **Use sentimentAnalysis.ts** - Integrate sentiment analysis into your own projects

## 💡 Bolt.new App Features

Once deployed, your app will have:

- 📝 **Sentiment Analyzer Tab**
  - Text input for airline tweets
  - Real-time sentiment classification
  - Confidence scores
  - Positive/negative word highlighting
  - Analysis history

- 📊 **Model Comparison Tab**
  - Interactive charts comparing all 7 ML models
  - Detailed performance metrics table
  - Methodology explanation
  - Dataset information

## 🤝 Contributing

This is a standalone project focused on airline sentiment analysis. Feel free to:
- Add more ML models
- Improve the sentiment analysis algorithm
- Enhance the bolt.new UI
- Integrate with live Twitter data (if API available)

---

**Ready to start?** Open `bolt-app-airline-sentiment.md` and begin building! 🚀
